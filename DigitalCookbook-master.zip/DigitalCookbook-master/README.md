# StudyAid
An android mobile app designed for my CMPS121- Mobile Applications class. A streamlined flashcard study app that is highly focused on usability and efficiency.

# What I learned
* Developing UI in xml using FrameLayouts and CardViews
* Creating and handling MySQL databases
* Implementing UI functionality: onClickListeners to flip cards and add new cards, swipe to go between cards, long press to edit
* Utilizing sensor data: Shake device to shuffle the deck of cards, twist to flip card
